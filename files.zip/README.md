# Test Discord Bot

A minimal Python Discord bot for testing, built with `discord.py`.

## Commands

Prefix commands (default prefix `!`):
- `!ping` — check latency
- `!hello` — say hello
- `!echo <message>` — repeats your message
- `!uptime` — how long the bot has been running
- `!serverinfo` — info about the current server

Slash command:
- `/info` — bot info (Python & discord.py versions, server count)

## Setup

1. **Create a bot application:**
   - Go to https://discord.com/developers/applications
   - Click "New Application", give it a name
   - Go to the "Bot" tab → click "Add Bot"
   - Under "Privileged Gateway Intents", enable **Message Content Intent** and **Server Members Intent**
   - Click "Reset Token" and copy the token (keep it secret!)

2. **Invite the bot to your server:**
   - Go to "OAuth2" → "URL Generator"
   - Select scopes: `bot`, `applications.commands`
   - Select permissions: at minimum `Send Messages`, `Read Message History`, `Embed Links`
   - Open the generated URL and add the bot to your server

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure your token:**
   - Copy `.env.example` to `.env`
   - Paste your bot token into `DISCORD_BOT_TOKEN`

5. **Run the bot:**
   ```bash
   python bot.py
   ```

You should see `Logged in as <YourBot>` in the console. Try `!ping` or `/info` in your server.

## Notes

- Never commit your `.env` file or share your token — treat it like a password.
- If slash commands don't show up immediately, wait a minute or restart your Discord client (global sync can take a little time on first run).
