"""
Test Discord Bot
-----------------
A simple starter bot demonstrating:
  - Prefix commands (!ping, !hello, etc.)
  - A slash command (/info)
  - Basic event handling
  - Loading the token from a .env file

Setup:
  1. pip install -r requirements.txt
  2. Copy .env.example to .env and paste your bot token in it
  3. python bot.py
"""

import os
import platform
import time
from datetime import datetime, timezone

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

load_dotenv()  # reads variables from a .env file into the environment
TOKEN = os.getenv("DISCORD_BOT_TOKEN")
COMMAND_PREFIX = os.getenv("COMMAND_PREFIX", "!")

if not TOKEN:
    raise RuntimeError(
        "No token found. Set DISCORD_BOT_TOKEN in your .env file "
        "(see .env.example)."
    )

# Intents control what data Discord sends your bot.
# message_content is required for prefix commands to read message text.
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix=COMMAND_PREFIX, intents=intents)
bot.launch_time = time.time()


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    print(f"Connected to {len(bot.guilds)} server(s).")
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} slash command(s).")
    except Exception as e:
        print(f"Slash command sync failed: {e}")

    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching, name=f"{COMMAND_PREFIX}help"
        )
    )


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send(f"Unknown command. Try `{COMMAND_PREFIX}help`.")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"Missing argument: `{error.param.name}`.")
    else:
        await ctx.send(f"Something went wrong: `{error}`")
        raise error


# ---------------------------------------------------------------------------
# Prefix commands
# ---------------------------------------------------------------------------

@bot.command(name="ping", help="Checks the bot's latency.")
async def ping(ctx):
    latency_ms = round(bot.latency * 1000)
    await ctx.send(f"Pong! Latency: {latency_ms}ms")


@bot.command(name="hello", help="Says hello back to you.")
async def hello(ctx):
    await ctx.send(f"Hello, {ctx.author.mention}! 👋")


@bot.command(name="echo", help="Repeats back whatever you type.")
async def echo(ctx, *, message: str):
    await ctx.send(message)


@bot.command(name="uptime", help="Shows how long the bot has been running.")
async def uptime(ctx):
    seconds = int(time.time() - bot.launch_time)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    await ctx.send(f"Uptime: {h}h {m}m {s}s")


@bot.command(name="serverinfo", help="Shows info about the current server.")
async def serverinfo(ctx):
    guild = ctx.guild
    if guild is None:
        await ctx.send("This command only works inside a server.")
        return

    embed = discord.Embed(
        title=guild.name,
        color=discord.Color.blurple(),
        timestamp=datetime.now(timezone.utc),
    )
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    embed.add_field(name="Members", value=guild.member_count)
    embed.add_field(name="Owner", value=str(guild.owner))
    embed.add_field(name="Created", value=guild.created_at.strftime("%Y-%m-%d"))
    embed.set_footer(text=f"Server ID: {guild.id}")

    await ctx.send(embed=embed)


# ---------------------------------------------------------------------------
# Slash command
# ---------------------------------------------------------------------------

@bot.tree.command(name="info", description="Shows info about the bot.")
async def info(interaction: discord.Interaction):
    embed = discord.Embed(
        title="Bot Info",
        color=discord.Color.green(),
    )
    embed.add_field(name="discord.py version", value=discord.__version__)
    embed.add_field(name="Python version", value=platform.python_version())
    embed.add_field(name="Servers", value=len(bot.guilds))
    await interaction.response.send_message(embed=embed)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    bot.run(TOKEN)
